class DistinctColumn {
  DistinctColumn({
    required this.discColumn,
    required this.color,
  });

  String? discColumn;
  int? color;
}