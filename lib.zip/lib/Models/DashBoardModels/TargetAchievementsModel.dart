class TargetAchievmentModel {
  final String year;
  final int sales;
  TargetAchievmentModel(this.year, this.sales);
}