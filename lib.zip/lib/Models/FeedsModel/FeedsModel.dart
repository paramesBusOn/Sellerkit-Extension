class FeedsMode
{
   String? name;
   String? title;
  String? desc;
   String? time;

   FeedsMode(this.time,this.desc,this.title,this.name);
}