class GridConValue{
  String? num;
  String? contect;
  String? color = '';//fcedee//b,ebf4fa//g,ebfaef
  GridConValue(this.contect,this.num ,this.color);
}