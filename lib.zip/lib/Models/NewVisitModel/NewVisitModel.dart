// ignore_for_file: non_constant_identifier_names

class ExistingCusData
{
  String? Customer;
  String? Mobile;
  String? CantactName;
  String? U_Address1;
  String? U_Address2;
  String? U_City;
  String? U_Pincode;
  String? U_State;
  String? U_Area;
  String? PurposOfVisit;
  String? Meeting_Time;
  String? Meeting_Date;
 String? AlterMobile;
  String? Email;
 String? GST;

  ExistingCusData({
required this.Customer,
required this.Mobile,
required this.CantactName,
required this.U_Address1,
required this.U_Address2,
required this.U_City,
required this.U_Area,
required this.PurposOfVisit,
required this.Meeting_Time,
required this.U_Pincode,
required this.U_State,
required this.Meeting_Date,
this.AlterMobile,
this.Email,
this.GST
  });

}
