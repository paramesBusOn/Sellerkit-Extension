String leadQueryTable = "LeadAnalysisQueryTable";

class LeadAnalysisQueryDB {
  static const String viewCode = 'ViewCode';
  static const String chartType = 'ChartType';
  static const String leadQuery = 'Query';
  static const String rowCode = 'RowCode';
  static const String queryExt = 'QueryExt';
  static const String kpiTitle = 'KPITitle';
}
