String leadViewTable = "LeadAnalysisViewTable";

class LeadAnalysisViewDB {
  static const String docEntry = 'DocEntry';
  static const String reportCode = 'ReportCode';
  static const String viewCode = 'ViewCode';
  static const String viewName = 'ViewName';
}
