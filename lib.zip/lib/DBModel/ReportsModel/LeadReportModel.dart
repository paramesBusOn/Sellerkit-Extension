 String leadReportTable = "LeadAnalysisReportTable";


class LeadAnalysisReportDB {
  static const String assignedTo = 'AssignedTo';
  static const String customerGroup = 'CustomerGroup';
  static const String leadDate = 'LeadDate';
  static const String nextFollowupDate = 'NextFollowupDate';
  static const String status = 'Status';
  static const String orderType = 'OrderType';
  static const String interestLevel = 'InterestLevel';
  static const String leadValue = 'LeadValue';
}
