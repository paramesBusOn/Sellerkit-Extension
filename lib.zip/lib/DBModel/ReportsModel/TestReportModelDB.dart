 String leadTestReportTable = "LeadTestReportTable";

class LeadTestReportDB {
  static const String title = 'Title';
  static const String testValues = 'TestValues';
}
