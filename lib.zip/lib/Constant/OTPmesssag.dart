import 'package:flutter/material.dart';

class OTPMessag {
  static String otpmsg =
      "https:// api.ultramsg.com/instance11070/messages/chat?token=f52pktts5h3t3c2e&to=+919159955413&body=Your%20OTP%20for%20Forget%20Password%20is%208332%20-%20Seller%20Kit&priority=10";
}
