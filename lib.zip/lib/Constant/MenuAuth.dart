class MenuAuthDetail {
  static String? ScoreCard='Y';
  static String? Earnings='Y';
  static String? Performance='Y';
  static String? Target='Y';
  static String? Challenges='Y';
  static String? Stocks='Y';
  static String? PriceList='Y';
  static String? OfferZone='Y';
  static String? Enquiries='Y';
  static String? Walkins='Y';
  static String? Leads='Y';
  static String? Orders='Y';
  static String? Followup='Y';
  static String? Accounts='Y';
  static String? Profile='Y';
  static String? Dashboard='Y';
  static String? KPI='Y';
  static String? Feeds='Y';
  static String? NewFeeds='Y';
  static String? Analytics='Y';
  //
  static String? Activities='Y';
  static String? DayStartEnd='Y';
  static String? Visitplane='Y';
  static String? SiteIn='Y';
  static String? SiteOut='Y';
  static String? LeaveRequest='Y';
  static String? LeaveApproval='Y';
  static String? Collection='Y';
  static String? Settlement='Y';
  
}