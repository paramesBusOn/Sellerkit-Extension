 import 'package:flutter/material.dart';

class Palettes {
  static const Color primary = Color(0xFF750537);
  static const Color primary2 = Color(0xFF01A0E1);//01A0E1 56D1E0
  static const Color primary3 = Color(0xFFFC7E26);

  //8D355C  AB587D  D087A8  FCB9D7
  }