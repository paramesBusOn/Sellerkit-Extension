// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:sellerkit/Pages/OrderBooking/Widgets/pos-widget/BottomButton.dart';
// import 'package:sellerkit/Pages/OrderBooking/Widgets/pos-widget/CashandCheque.dart';
// import 'package:sellerkit/Pages/OrderBooking/Widgets/pos-widget/CustomerDetails.dart';
// import 'package:sellerkit/Pages/OrderBooking/Widgets/pos-widget/ItemLists.dart';
// import 'package:sellerkit/Pages/OrderBooking/Widgets/pos-widget/Paymentpage.dart';
// import '../../../../Constant/Screen.dart';

// class SObillingTabScreen extends StatefulWidget {
//   const SObillingTabScreen({
//     Key? key,
//     required this.theme, // required this.prdSCD
//   }) : super(key: key);

//   final ThemeData theme;

//   @override
//   State<SObillingTabScreen> createState() => _SObillingTabScreenState();
// }

// class _SObillingTabScreenState extends State<SObillingTabScreen> {
//   // SOCon prdSCD;
//   @override
//   Widget build(BuildContext context) {
//     return 
//   }
// }
